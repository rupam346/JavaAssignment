package com.cg.CollectionImplementation;

import java.util.HashMap;
import java.util.Map;

public class MapDemo 
{
	public static void main(String[] args) 
	{
		Map<String, Integer> map= new HashMap<>();
		map.put("E", 82);
		map.put("A", 55);
		map.put("D", 73);
		map.put("C", 85);
		map.put("B", 95);
		
		for(Map.Entry entry:map.entrySet()) 
		{
			System.out.println(entry.getKey()+" : "+entry.getValue());
		}

		map.containsKey("B");
		map.put("F", null);
		map.put("X", null);
		map.put(null, 48);
		map.put(null, 70);   
		
		System.out.println(map.entrySet());
	}
}

