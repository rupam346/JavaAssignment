package com.cg.CollectionImplementation;

import java.util.Map;
import java.util.TreeMap;

public class TreeMapDemo {
	
void student(){
	Map<String, Character> treemap= new TreeMap<>();
	treemap.put("Goutham", 'A');
	treemap.put("Akshay", 'B');
	treemap.put("Roshan", 'C');
	treemap.put("Suresh", 'D');
	treemap.put("Chandana", 'E');
	for(Map.Entry mp: treemap.entrySet()) {
	
		System.out.println("Student "+mp.getKey()+" is belongs to "+mp.getValue()+" division");	
	}
}
	
public static void main(String[] args) {
	TreeMapDemo demo= new TreeMapDemo();
	demo.student();
}
}
