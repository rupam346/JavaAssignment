package com.cg.AccessModifierImplementation;

public class PrivateUseCase {

		 private void add(int a,int b) {
			int sum=a+b;
			System.out.println("Sum of a and b ="+sum);
		 }
			
			 static void main(String[] args) {
		   PrivateUseCase priv= new PrivateUseCase();
			priv.add(566677, 8899);

			}

}
