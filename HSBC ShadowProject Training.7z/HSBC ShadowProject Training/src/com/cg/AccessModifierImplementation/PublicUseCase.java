package com.cg.AccessModifierImplementation;

public class PublicUseCase {

		public static void square(double a) {
			
			
			System.out.println("Square of number = "+a*a);
		}
		public static void main(String[] args) {
			square(5);
			ProtectedUseCase.cube(5);
			DefaultUseCase.factorial(5);
			PrivateUseCase priv= new PrivateUseCase();
			//priv.add(566677, 8899);
		}
		}

