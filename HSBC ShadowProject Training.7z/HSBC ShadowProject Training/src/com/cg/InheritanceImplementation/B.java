package com.cg.InheritanceImplementation;

//Single Inheritance

class A{
void showA(){
		System.out.println("This is parent/base class");
	}
}

class B extends A {
         
    void showB() {
		System.out.println("This is child/sub class ");
	}
	
public static void main(String[] args) {
	A j = new A();
	j.showA();
	B i = new B();
    i.showA();
    i.showB();
	}

}
