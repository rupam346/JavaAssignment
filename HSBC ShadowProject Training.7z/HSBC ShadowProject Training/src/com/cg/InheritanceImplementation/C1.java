package com.cg.InheritanceImplementation;

//hierarchical  Inheritance



class A2
{
	void showA() 
	{
		System.out.println("A class method");
	}
}
class B2 extends A2
{
	void showB() 
	{
		System.out.println("B class method");
	}
}
class C1 extends A2
{
	void showC()
	{
		System.out.println("C class method");
	}
	public static void main(String[] args)
	{
		
		A2 obj1 = new A2();
		obj1.showA();
		System.out.println("----------------------------------------");
		B2 obj2 = new B2();
		obj2.showA();
		obj2.showB();
		System.out.println("----------------------------------------");
		C1 obj3 = new C1();
		obj3.showA();
		//obj3.showB();
		obj3.showC();
	}
}

