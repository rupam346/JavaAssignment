package com.cg.InheritanceImplementation;

//Multilevel  Inheritance

class A1
{
	void showA() 
	{
		System.out.println("A class method");
	}
}
class B1 extends A1
{
	void showB() 
	{
		System.out.println("B class method");
	}
}
class C extends B1
{
	void showC()
	{
		System.out.println("C class method");
	}
	public static void main(String[] args)
	{
		
		A1 obj1 = new C();
		obj1.showA();
		System.out.println("----------------------------------------");
		B1 obj2 = new C();
		obj2.showA();
		obj2.showB();
		System.out.println("----------------------------------------");
		C obj3 = new C();
		obj3.showA();
		obj3.showB();
		obj3.showC();
	}
}