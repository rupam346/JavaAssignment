package com.cg.TrainingAssignment;

public class Assignment30 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int rows = 5;
		  
	      for (int i = 1; i <= rows; ++i) 
	      {
	        for (int j = 1; j <= i; ++j) 
	        {
	          System.out.print("* ");
	        }
	        System.out.println();
	      }

	      System.out.println("Next Pattern");
	      for (int i = 1; i <= rows; ++i) 
	      {
	        for (int j = 1; j <= i; ++j) 
	        {
	          System.out.print(j + " ");
	        }
	        System.out.println();
	      }


}
}
