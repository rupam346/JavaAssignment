package com.cg.TrainingAssignment;

public class Assignment7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char[] ch = {'a', 'e', 'i', 'o', 'u'};

        String st = String.valueOf(ch);
        String st2 = new String(ch);

        System.out.println(st);
        System.out.println(st2);
	}

}
