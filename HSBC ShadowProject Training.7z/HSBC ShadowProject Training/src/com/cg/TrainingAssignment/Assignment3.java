package com.cg.TrainingAssignment;

import java.util.Scanner;

public class Assignment3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string to check whether it is palindrome or not");
		String s = sc.next();
		System.out.println(PalindromeChecker.isPalindrome(s));

	}
}

 class PalindromeChecker{
 public static boolean isPalindrome(String str) {
	StringBuilder sb = new StringBuilder(str);
	sb.reverse();
	String rev = sb.toString();
	if(sb.equals(rev)) {
		return true;
	}
	else {
		return false;
	}
}
}
	

