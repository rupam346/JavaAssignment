package com.cg.TrainingAssignment;

public class Assignment17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char c;
		  
	      for(c = 'a'; c <= 'z'; ++c)
	        System.out.print(c + " ");
	}

}
