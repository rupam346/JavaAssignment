package com.cg.TrainingAssignment;

public class Assignment15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  char c = 'A';
        
        String output = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')
                ? c + " is an alphabet."
                : c + " is not an alphabet.";
        
        System.out.println(output);
	}

}
