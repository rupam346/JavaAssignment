package com.cg.TrainingAssignment;

import java.util.ArrayList;

public class Assignment25 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList languages = new ArrayList<>();

	    languages.add("Java");
	    languages.add("Python");
	    languages.add("JavaScript");
	    System.out.println("ArrayList: " + languages);

	    String[] arr = new String[languages.size()];

	    languages.toArray(arr);
	    System.out.print("Array: ");
	    for(String item:arr)
	     {
	      System.out.print(item+", ");
	    }
	}

}
