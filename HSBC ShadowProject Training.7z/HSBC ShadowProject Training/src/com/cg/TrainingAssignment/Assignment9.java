package com.cg.TrainingAssignment;

public class Assignment9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] numArray = { 23, 34, 500, 33, 55, 43, 5, 66 };
	        double largest = numArray[0];

	        for (int num: numArray) {
	            if(largest < num)
	                largest = num;
	        }

	        System.out.format("Largest element = "+ largest);
	}

}
