package com.cg.TrainingAssignment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Assignment11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] array = {"Java", "Python", "C"};
	    System.out.println("Array: " + Arrays.toString(array));

	    List languages= new ArrayList<>(Arrays.asList(array));

	    System.out.println("List: " + languages);
	}

}
