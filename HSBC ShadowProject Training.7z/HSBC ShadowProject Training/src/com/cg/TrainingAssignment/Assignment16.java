package com.cg.TrainingAssignment;

public class Assignment16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int num = 5;
	        for(int i = 1; i <= 10; ++i)
	        {
	            System.out.printf("%d * %d = %d \n", num, i, num * i);
	        }
	}

}
