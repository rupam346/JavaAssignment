package com.cg.TrainingAssignment;

import java.util.Scanner;

public class Assignment1 {

	public static void main(String arg[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a no. to check no. is prime or composite");
		int n = sc.nextInt();
		int flag =0;
		
		for(int i=2 ; i<n; i++) {
			if(n%i == 0) 
				flag++;
			
		}
	if(flag > 0 )
		System.out.println(n + " is a composite no.");
	else
		System.out.println(n+ " is a prime no.");
	}
}
