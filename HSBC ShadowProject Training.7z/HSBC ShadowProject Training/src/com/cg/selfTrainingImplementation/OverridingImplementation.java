package com.cg.selfTrainingImplementation;

/*class Test{
	void show() {
		System.out.println("1");
	}
}              
public class OverridingImplementation extends Test {
     void show() {
    	  System.out.println("2");
      }
public static void main(String[] args) {
		// TODO Auto-generated method stub
//      Test t = new Test();
//      t.show();
  OverridingImplementation u = new OverridingImplementation();
  u.show();                             */
//-------------------------------------------------------------------------------------------------------------	
//  Do overriding method must have same return type(or subtype)
//yes ,after 1.4v  we can use covariant return type i.e child class ka parent class ko use kr skte h as a different return type
  class Test{
	  Object show() {
		  System.out.println("1");
		  return null;
	}
}
  public class OverridingImplementation extends Test{
	  String show() {
		  System.out.println("4");
		  return null;
	  }    //child class ki method ki accessibility jada honi chahiye as compare to parent class like parent-default and child ki public honi chahiye
	public static void main(String []args) {
		OverridingImplementation u = new OverridingImplementation();
		u.show();
	}
  }
  
