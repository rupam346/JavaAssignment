package com.cg.selfTrainingImplementation;

abstract class Vehicle {
     abstract void start();
}

class Car extends Vehicle{
	void start() {
		System.out.println("Car start with kick");
	}
}

class ScooterAbstractImplementation extends Vehicle{
	void start() {
		System.out.println("Scooter start with kick");
	}
	public static void main(String[] args) {
//Vehicle v = new Vehicle();  - Vehicle is abstract class so it can't be instansiated
		Car c = new Car();
		c.start();
		
		ScooterAbstractImplementation s = new ScooterAbstractImplementation();
		s.start();
	}
}
