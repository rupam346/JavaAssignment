package com.cg.selfTrainingImplementation;

import java.util.Scanner;

public class ControlFlowStatement {

	public static void main(String []args) {
//  -------------------  IF  ----------------------------	
/*	int var =4;
		if(var%2 == 0) {
			System.out.println("I am an even");
		}
		
	System.out.println("Default value");                              */
	
//---------------------------  TERNARY  OPERATOR - IT IS A SHORT HAND WAY OF IF-ELSE STATEMENT
/*	
	int n = (var % 2 == 0) ? var +1 : var + 2;
	System.out.println(n);                           */
		
//---------------------------  IF-ELSE-LADDER  ----------------------------------------
	/*	int var = 7;
		if(var%2 == 0)
			System.out.println("Multiple of 2");
		else if(var%5 == 0)
			System.out.println("Multiple of 5");
		else if(var%3 == 0)
			System.out.println("Multiple of 3");
		else
			System.out.println("Gikific");                         */
		
//--------------------------  SWITCH  ------------------------------------
		//All switch case share the same scope so we can't define same variable in 2 switch cases so we can put curly braces to remove it
Scanner sc = new Scanner(System.in);
		String today = 	sc.nextLine();	
		switch(today) {
		case "MONDAY","TUESDAY","WEDNESDAY":
			
		case "THURSDAY" , "FRIDAY":{
			String msg = "Geekific";
			break;
		}	
		case "SATURDAY" ," SUNDAY" :{
			String msg = "Geekific";
			break;
		}
		}
		}
	}

