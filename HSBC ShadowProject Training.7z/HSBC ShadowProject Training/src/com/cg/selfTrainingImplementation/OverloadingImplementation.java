package com.cg.selfTrainingImplementation;

public class OverloadingImplementation {

/*	  void show() {
		System.out.println("1");  
	  }
	  void show(int a) {
		  System.out.println("2" +a);
	  }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OverloadingImplementation obj = new OverloadingImplementation();
		obj.show();
		obj.show(9);   */
	
// Can we overload main() method?  - Yes ,coz jvm calls main method which receive string array as argument
/*	public static void main(String[] args) {
		System.out.println("1");
		OverloadingImplementation obj = new OverloadingImplementation();
		obj.main(7);
	}
	public static void main(int a) {
		System.out.println("5");
	}          */
	
//AUTOMATIC  PROMOTION
 /*	void show(int a) {
		System.out.println("int method");
	}
	void show(String a) {
		System.out.println("String method");
	}
	public static void main(String[] args) {
		OverloadingImplementation obj = new OverloadingImplementation();
		obj.show('b');  // char is passed but it will get promoted to int 
	}        */
	
	
/*void show(StringBuffer a) {
	System.out.println("stringbuffer method");
}
void show(String a) {
	System.out.println("String method");
}
public static void main(String[] args) {
OverloadingImplementation obj = new OverloadingImplementation();
        obj.show("abc");
        obj.show(new StringBuffer("xyz"));
     //   obj.show(null);  -it will show error  as string and stringbuffer r at same level so compiler will get confused
 }
 */
	
//VARARG - VARIABLE ARGUMENT
void show(int a) {
	System.out.println("int variable");
}
void show(int... b) {
	System.out.println("variable  arguments");
}
public static void main(String args[]) {
	OverloadingImplementation obj = new OverloadingImplementation();
	obj.show(23);
	obj.show(12, 67, 45);
}
}
