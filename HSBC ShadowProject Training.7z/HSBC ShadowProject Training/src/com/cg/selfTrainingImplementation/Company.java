package com.cg.selfTrainingImplementation;

//Implementation on Encapsulation

class Employee{
 private int emp_id;   // data hiding
  public void setEmp_id(int empId) {
	   emp_id = empId;
  }
 public int getEmp_id() {
	 return emp_id;
 }
}

class Company {

	public static void main(String[] args) {

       Employee e = new Employee();
         e.setEmp_id(3434);
         System.out.println("To view data :"+e.getEmp_id());
	}

}
