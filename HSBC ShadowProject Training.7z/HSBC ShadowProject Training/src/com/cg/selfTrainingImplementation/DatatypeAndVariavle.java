package com.cg.selfTrainingImplementation;

public class DatatypeAndVariavle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String myVar = "Hello World!!";
        int totalMoney = 1000;
        
//if we have to print $ sign with amount then we can use String as int will show error   
        String money = "23545 $";
        
//int money1 = 14455.6;  it will show error since java consider . as double , to take it as float we have to use "f""F" with it
        float money1 = 2345.889f;
        double money2 = 3456.89;
        
//if we only want to print $ then String will simply waste memory so we can use char within single quote
        char useDollar = '$';
        System.out.println(totalMoney);
	}

}
