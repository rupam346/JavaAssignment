package com.cg.selfTrainingImplementation;

public class ImplementationOfConstructor {
	int i;
	String s;
	/*     Default Constructor
         public static void main(String[] args) {
        	 ImplementationOfConstructor t = new ImplementationOfConstructor();
        	 System.out.println(t.i);
         }                                */
//----------------------------------------------------------------------------------------------	
/*	no Argument constructor
	ImplementationOfConstructor(){
		System.out.println("This is a no argument constructor");
	}
	public static void main(String[] args) {
   	 ImplementationOfConstructor t = new ImplementationOfConstructor();
	}                               */
//---------------------------------------------------------------------------------------------	
//	Parameterised  constructor
	ImplementationOfConstructor(int a){
		System.out.println("This is a parameterised constructor");
	}
	public static void main(String[] args) {
	   	 ImplementationOfConstructor t = new ImplementationOfConstructor(230);
		} 
}
