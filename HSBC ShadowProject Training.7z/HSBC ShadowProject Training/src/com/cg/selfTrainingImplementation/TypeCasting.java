package com.cg.selfTrainingImplementation;

public class TypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//implicit type conversion
       int a = 10;
       long b = a;                           
       float c = a;
       System.out.println(a + " "+b+" "+c);
   //Explicit type conversion
       double m = 71.5;
       System.out.println("The double value is: "+m);
       int n = (int)m;   //since double is wider than int so it will throw error
       System.out.println("The integer value is "+n);
       float g = (float)m;
       System.out.println("The float value is "+g);
       
	}

}
