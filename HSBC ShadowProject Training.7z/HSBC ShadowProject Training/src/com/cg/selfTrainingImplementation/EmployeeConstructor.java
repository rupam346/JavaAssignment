package com.cg.selfTrainingImplementation;

class EmployeeConstructor {
	String name;
	int emp_id;
	
        EmployeeConstructor(String name , int emp_id) {
    	   this.name = name;
    	   this.emp_id = emp_id;
       }
        
  public static void main(String []args) {
	  EmployeeConstructor e1 = new EmployeeConstructor("Deepak" , 465373);
	  EmployeeConstructor e2 = new EmployeeConstructor("Rakesh" , 465385);
	  System.out.println("Employee 1 : "+e1.name+" "+e1.emp_id);
	  System.out.println("Employee 2 : "+e2.name+" "+e2.emp_id);
  }
}
