package com.cg.selfTrainingImplementation;

public class TwoDArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     
		int [][]WorldPopulation = {
				                    {234, 566, 121, 786},
				                    {123 , 893, 305, 174},
				                    {041 , 576, 103, 495}
		                          } ;
		
		for(int i=0; i<WorldPopulation.length ; i++) {
			for(int j=0 ; j<WorldPopulation[i].length ; j++ ) {
				System.out.print(WorldPopulation[i][j]+" ");
			}
			 System.out.println();
		}
		}
	}


