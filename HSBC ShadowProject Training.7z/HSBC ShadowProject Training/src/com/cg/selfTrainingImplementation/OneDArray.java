package com.cg.selfTrainingImplementation;

import java.util.Scanner;

public class OneDArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   //Single Value Container
	/*	int State1PopulationCount = 345;
		int State2PopulationCount = 123;
		int State3PopulationCount = 875;
		                  */
	
		Scanner sc = new Scanner(System.in);
  
		//Multi Value Container
		 
		int []StatePopulation = new int[6];                               //bydefault its value is 0
		//int []StatePopulation = {234, 674, 240, 274, 595, 382};         // Elements have some default initial value and its an implicit way
	   //int []StatePopulation = new int[]{234, 674, 240, 274, 595, 382};    its an explicit way
	
		//System.out.println("Population of country "+StatePopulation[1]);
		System.out.println("Enter the value in array for operation");
		
		for(int i=0 ; i<StatePopulation.length ; i++ ) {
	     StatePopulation[i] = sc.nextInt();
		 //System.out.print(StatePopulation[i] +" ");
		}           
		
//     Enhanced  For Loop or ForEach Loop
		int count=0;
		for(int efl : StatePopulation) {
			System.out.println(efl);
			count += efl;
		}
		System.out.println("Population of entire country is "+count);
	}

}
