package com.cg.selfTrainingImplementation;

import java.util.Scanner;

public class DifferentLoops {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//--------------------------------    WHILE LOOP - it check condition and then execute
	/*	int i =5;
		while(i>0) {
		System.out.print(i +" ");
		i--;
		}                                     */
//-------------------------------    FOR LOOP	 -----------------------------------
	/*	for(int b =0 ; b < 12 ; b++) {
			System.out.print(b +" ");
			int n = b;
			b = b +n;
		}                                       */
		
//-------------------------------    DO WHILE - it execute once then check condition		

Scanner sc = new Scanner(System.in);
     int n;
     do {
    	
    	 System.out.println("enter a no. between 1 and 10");
    	 n = sc.nextInt();
     }
     while(n<1 || n>10);
     
     System.out.println(n +" is between 1 and 10" );
	}

}
