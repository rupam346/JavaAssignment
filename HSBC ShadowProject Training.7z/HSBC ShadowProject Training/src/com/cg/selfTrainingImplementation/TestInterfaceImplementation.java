package com.cg.selfTrainingImplementation;

interface Test1 {
	//public static final	int a =10;  -All variables inside Interface is by default public static and final

    void show();  //Method in Interface is always  abstract and public by default
  // void display() {}            Interface abstract method cannot have body
   
   
 //  default void display() { }     - It is possible to create default method with body of interface
 //  static void disc1() {}         -we can also create static method with body in interface
}

interface Test2{
	void display();
}

class TestInterfaceImplementation implements Test1 ,Test2{
 public	void show() {      //it should be public because show method in interface is public
		System.out.println("47253");
	}
 
 public void display() {
	 System.out.println("This is multiple Inheritance");
 }
 
 public static void main(String []args) {
 //TestInterfaceImplementation I1 = new TestInterfaceImplementation();  - we can't make object of interface class
	TestInterfaceImplementation t1 = new TestInterfaceImplementation();
	t1.show();
	t1.display();
 }
}