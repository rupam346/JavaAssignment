package com.cg.selfTrainingImplementation;

public class DiffOperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	//INCREMENT OPERATOR
		
		int age = 10;
		System.out.println(age++);   // it'll give 10
		System.out.println(++age);    // ++11 ,so ans will be 12
		
		System.out.println(age++ + ++age); //for add left to right = 12 +14(++13) =26
		
    //LOGICAL  OPERATOR
		int num1 = 10;
		int num2 = 20;
		
		boolean A = num1>50;
		boolean B = num2>5;
		
		System.out.println(A&&B);  //true
		System.out.println(!(A||B));

	}

}
