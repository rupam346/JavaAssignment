package com.cg.selfTrainingImplementation;

import java.util.Scanner;

public class DiffString {

	public static void main(String []arg) {
		String str1, str2;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter 1st string");
		str1 = sc.nextLine();
		System.out.println("Enter 2nd string ");
	    str2 = sc.nextLine();
		System.out.println("concatinating both string " +str1+" " +str2);
		System.out.println("length of strings are "+str1.length() +" "+str2.length());
		System.out.println(str1.toLowerCase() + " " + str2.toUpperCase());
		
	}
}
